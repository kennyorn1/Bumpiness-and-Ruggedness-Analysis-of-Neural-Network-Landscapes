import numpy as np
import plotly.graph_objects as go

# import matplotlib as plt

# fig = go.Figure(data=go.Streamtube(x=[0, 0, 0], y=[0, 1, 2], z=[0, 1, 2],
#                                    u=[2, 1, 0.5], v=[2, 1, 0.5], w=[2, 1, 0.5]))
# fig.show()


# mat = np.array([[1, -1], [1, 1]])

# eigenvalue, featurevector = np.linalg.eig(mat)
# abs_trace = len([num for num in np.abs(eigenvalue) if num > 0])
# print(np.trace(mat))
# print("特征值：", eigenvalue)
# print("特征向量：", featurevector)
# print(np.max(np.abs(mat)))

from matplotlib import pyplot as plot
import numpy as np
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# fig = plt.figure()  # 定义新的三维坐标轴
# ax3 = plt.axes(projection='3d')

# # 定义三维数据
# xx = np.arange(-5, 5, 0.5)
# yy = np.arange(-5, 5, 0.5)
# X, Y = np.meshgrid(xx, yy)
# Z = 0*X+0*Y


# # 作图
# ax3.plot_surface(X, Y, Z, cmap='rainbow')
# # ax3.contour(X,Y,Z, zdim='z',offset=-2，cmap='rainbow)   #等高线图，要设置offset，为Z的最小值
# fig.savefig('平面图.png', dpi=300)

fig = plt.figure()  # 定义新的三维坐标轴
ax3 = plt.axes(projection="3d")

# 定义三维数据
xx = np.arange(-1, 1, 0.01)
yy = np.arange(-1, 1, 0.01)
X, Y = np.meshgrid(xx, yy)
Z = X**4 - Y**4


# 作图
ax3.plot_surface(X, Y, Z, cmap="rainbow")
# ax3.contour(X,Y,Z, zdim='z',offset=-2，cmap='rainbow)   #等高线图，要设置offset，为Z的最小值
# fig.savefig('马鞍图.png', dpi=300)

plt.show()


# positive_count = len([num for num in eigenvalue.real if num > 0])
# if positive_count > 0:
#     positive_eigenvalues = [num for num in eigenvalue if num.real > 0]
#     convexity_ruggedness = np.sum(np.abs(positive_eigenvalues)) / dimen
# else:
#     convexity_ruggedness = 0

# negative_count = len([num for num in eigenvalue.real if num < 0])
# if negative_count > 0:
#     negative_eigenvalues = [num for num in eigenvalue if num.real < 0]
#     concavity_ruggedness = np.sum(np.abs(negative_eigenvalues)) / dimen
# else:
#     concavity_ruggedness = 0

# zero_count = len([num for num in np.abs(eigenvalue) if num == 0])

# bumpiness = convexity_ruggedness - concavity_ruggedness
# bumpiness = bumpiness / ruggedness
